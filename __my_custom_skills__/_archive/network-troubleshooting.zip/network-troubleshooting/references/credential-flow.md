# Credential Flow

## Process Chain
**Nautobot** → **Vault** → **SSH**

## Steps

1. **Get device from Nautobot:** Extract secrets_group ID and management IP
2. **Get secrets group:** Query secrets group for secret IDs
3. **Get secret details:** For each secret, get Vault path and key
4. **Retrieve from Vault:** Use path/key to get actual username/password  
5. **Connect via SSH:** Use credentials with SSH MCP

## Example

```
1. GET /api/dcim/devices/?name=switch-01
   → secrets_group: {id: "abc-123"}, primary_ip4: "10.1.1.10"

2. GET /api/extras/secrets-groups/abc-123/
   → secrets: [{secret: {id: "secret-1"}}, {secret: {id: "secret-2"}}]

3. GET /api/extras/secrets/secret-1/
   → parameters: {path: "secret/data/network/switches", key: "username"}

4. vault_read("secret/data/network/switches", "username")
   → "admin"

5. ssh_runRemoteCommand("10.1.1.10", "show version")
```

Always follow complete chain for every device connection.
