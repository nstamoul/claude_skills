# Cisco IOS/IOS-XE Commands

## Layer 3

**ARP table:**
```
show ip arp | include <ip>
```

**Routing:**
```
show ip route <ip>
```

## Layer 2

**MAC address table:**
```
show mac address-table address <mac>
```

**VLANs:**
```
show vlan brief
```

## Interface Health

**Status and rates:**
```
show interface <intf>
show interface <intf> | include rate|drop|error|CRC
```

**Counters:**
```
show interface <intf> counters errors
```

## Discovery

**CDP neighbors:**
```
show cdp neighbors detail
```

## Troubleshooting

**Ping:**
```
ping <ip>
```

**Traceroute:**
```
traceroute <ip>
```

## Common Patterns

Find device by IP:
1. `show ip arp | include <ip>` → get MAC
2. `show mac address-table address <mac>` → get port

Check interface health:
```
show interface <intf> | include rate|drop|error
```
