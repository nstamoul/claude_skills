# Cisco NX-OS Commands

## Key Differences from IOS
- VRF must be specified: `vrf all`
- Different output formats
- JSON output supported: `| json`

## Layer 3

**ARP table (all VRFs):**
```
show ip arp vrf all | include <ip>
```

**Routing:**
```
show ip route <ip>
show ip route vrf all | include <ip>
```

## Layer 2

**MAC address table:**
```
show mac address-table address <mac>
```

## Interface Health

**Status:**
```
show interface <intf>
show interface brief
```

**Counters and errors:**
```
show interface <intf> counters
show interface <intf> counters errors
show interface <intf> counters rates
```

## Discovery

**CDP/LLDP:**
```
show cdp neighbors detail
show lldp neighbors detail
```

## Common Pattern

Find device by IP:
1. `show ip arp vrf all | include <ip>` → get MAC
2. `show mac address-table address <mac>` → get port
