# Cisco Firewall Commands (ASA/Firepower)

## Cisco ASA

**Active connections:**
```
show conn | include <ip>
```

**Access lists:**
```
show access-list | include <ip>
show access-list <acl-name>
```

**Packet tracer (most useful!):**
```
packet-tracer input <intf> <proto> <src-ip> <sport> <dst-ip> <dport>
```
Example:
```
packet-tracer input inside tcp 192.168.1.10 12345 10.100.5.10 443
```

Shows ACL matches, NAT, routing decisions, permit/deny.

**NAT:**
```
show xlate | include <ip>
```

**Routing:**
```
show route <ip>
```

**Logging:**
```
show logging | include Deny
show logging | include <ip>
```

## Troubleshooting Workflow

1. Use packet-tracer to simulate traffic
2. Check ACLs if blocked
3. Verify NAT translations
4. Check routing for both directions
5. Review logs for denies

**Enable debug (use sparingly):**
```
debug access-list <acl>
debug conn
```

**Disable:**
```
undebug all
```
