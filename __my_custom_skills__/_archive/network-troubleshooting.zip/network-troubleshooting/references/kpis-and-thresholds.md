# Network KPIs and Thresholds

## Interface Utilization

**Check:** `show interface <intf> | include rate`

**Thresholds:**
- 0-60%: Normal
- 60-80%: Elevated (monitor)
- 80-90%: High (investigate)
- 90-100%: Critical (immediate action)

**Note:** Sustained >80% causes drops and latency.

## Packet Drops

**Check:** `show interface <intf> | include drops`

**Calculation:** Drop Rate % = (Drops / Total Packets) × 100

**Thresholds:**
- 0: Ideal
- <0.1%: Acceptable
- 0.1-1%: Concerning
- >1%: Critical

**Types:**
- **Input drops:** Buffer overruns, congestion receiving
- **Output drops:** Egress congestion, QoS drops

## CRC Errors

**Check:** `show interface <intf> | include CRC`

**Thresholds:**
- 0: Ideal
- 1-100: Monitor for increase
- 100-1000: Investigate physical layer
- >1000: Critical - replace cable/SFP

**Causes:**
- Bad cable (most common)
- Defective SFP
- Dirty fiber connectors
- EMI
- Duplex mismatch
- Hardware failure

## Collisions

**Check:** `show interface <intf> | include collision`

**Critical:** Full-duplex links should NEVER have collisions!

**If collisions on full-duplex:**
- Duplex mismatch present
- Fix duplex settings immediately

## Frame Errors

**Types:**
- Runts: < 64 bytes
- Giants: > MTU
- Alignment errors

**Similar thresholds to CRC errors.**

## Latency (RTT)

**Check:** `ping <ip>`

**LAN Thresholds:**
- <1ms: Excellent
- 1-5ms: Good
- 5-20ms: Acceptable
- 20-100ms: Degraded
- >100ms: Poor

## Symptom Correlation

| Symptoms | Likely Cause | Priority |
|----------|--------------|----------|
| High util + drops | Capacity issue | High |
| CRC + collisions | Duplex mismatch | High |
| CRC only | Physical layer | High |
| Drops + low util | Config/QoS issue | Medium |

## Best Practices

1. Establish baselines for your network
2. Monitor trends, not just point values
3. Brief spikes may be normal
4. Correlate multiple metrics for root cause
5. Document normal vs. current values
