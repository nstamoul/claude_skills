# Nautobot API Reference

## Authentication

All API requests require an API token in the header:
```
Authorization: Token YOUR_API_TOKEN
```

**Base URL:** `https://sot.nstam.eu/api`

## Common Endpoints

### Devices

**Get device by name:**
```
GET /dcim/devices/?name=<device-name>
```

Response includes secrets_group, primary_ip4, platform, device_type, etc.

### IP Addresses

**Find IP address:**
```
GET /ipam/ip-addresses/?address=<ip-address>
```

**Get IPs in subnet:**
```
GET /ipam/ip-addresses/?parent=<prefix>
```

### Prefixes

**Find prefix containing IP:**
```
GET /ipam/prefixes/?contains=<ip-address>
```

### Cables

**Get cables for device:**
```
GET /dcim/cables/?device=<device-name>
```

Returns a_terminations and b_terminations showing connections.

### Secrets

**Get secrets group:**
```
GET /extras/secrets-groups/<id>/
```

**Get secret details:**
```
GET /extras/secrets/<uuid>/
```

Returns vault path and key in parameters field.
