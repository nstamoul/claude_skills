# Fortigate Firewall Commands

## Active Sessions

**View sessions:**
```
get system session list
```

**Filter by IP:**
```
diagnose sys session filter src <ip>
diagnose sys session list
```

**Clear filters:**
```
diagnose sys session clear
```

## Firewall Policies

**View policies:**
```
show firewall policy
```

## Flow Debug (Most Powerful Tool!)

**Enable for specific traffic:**
```
diagnose debug flow filter saddr <source-ip>
diagnose debug flow filter daddr <dest-ip>
diagnose debug flow show console enable
diagnose debug flow trace start 100
diagnose debug enable
```

Shows policy match, NAT, routing, permit/deny decisions.

**Disable:**
```
diagnose debug disable
diagnose debug reset
```

## Routing

**Routing table:**
```
get router info routing-table all
get router info routing-table details <ip>
```

## Sniffer (Packet Capture)

**Capture packets:**
```
diagnose sniffer packet <intf> 'host <ip>' 4 100
```

Verbose levels: 1-6 (4 = header with interface name)

## Troubleshooting Workflow

1. Enable flow debug for specific source/dest IPs
2. Generate or wait for traffic
3. Analyze output (policy match, NAT, routing)
4. Disable debug
5. Check policies if needed
6. Verify routing both directions

## Logs

**Real-time logs:**
```
execute log filter field srcip <ip>
execute log filter field dstip <ip>
execute log display
```

**Clear filters:**
```
execute log filter clear
```

## Ping/DNS

**Ping:**
```
execute ping <ip>
```

**DNS:**
```
execute dns lookup <hostname>
```
