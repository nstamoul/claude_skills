---
name: network-troubleshooting
description: Troubleshoot enterprise network issues using the Orchestration MCP toolchain (Nautobot, Vault, Nornir). Diagnose connectivity, locate devices, trace paths, and validate firewall behaviour using structured JSON outputs from `execute_network_task` and related tools.
---

# Network Troubleshooting Skill

## Overview

This skill leverages the **Orchestration MCP** as the single entry point for network diagnostics. Behind the scenes the orchestrator coordinates three MCP backends:

1. **Nautobot MCP** – GraphQL inventory, cabling, prefixes, tenant metadata.
2. **Vault MCP** – device credentials per tenant (`<tenant>/login`).
3. **Nornir MCP** – executes CLI / config / Napalm tasks with TextFSM parsing to return structured JSON (when templates exist) or raw text otherwise.

All orchestrator tool calls use JSON-RPC (Claude-compatible). Prefer the HTTP transport; stdio mode is available for ad hoc testing.

## Core Tools (Orchestration MCP)

| Tool | Purpose | Output / Usage Tips |
|------|---------|---------------------|
| `prepare_nornir_inventory` | Preview devices for tenant/location filters. | Returns JSON inventory (`hosts`, `defaults`, `groups`); supply `limit` to cap results. |
| `list_nornir_backends` | Show configured Nornir backends (`macbook`, `wsl`, `wyze`). | Pick the backend already on the VPN; backends expect host networking on Orbstack. |
| `get_devices` | Direct Nautobot queries (GraphQL via MCP). | Pass filters as arrays and set `format: "inventory"` for the lean JSON payload. |
| `vault_read` | Retrieve credentials (`<tenant>/login`). | Orchestrator caches per tenant automatically; call only for manual inspection. |
| `execute_network_task` | **Primary entry point.** Execute CLI/config/Napalm tasks. | Returns per-host command map with `parsed` flag and structured rows when TextFSM matches. |

### JSON-RPC Calling Pattern

All orchestrator interactions use JSON-RPC (`method: "tools/call"`). Keep every filter field as a list, even for single items (`"platform": ["cisco_xe"]`). Set optional knobs up front (`format`, `limit`, `nornir_backend`) so Claude can reason over predictable response shapes.

### Example (run `show version` on AXEPA access switches)
```json
{
  "jsonrpc": "2.0",
  "id": "exec-1",
  "method": "tools/call",
  "params": {
    "name": "execute_network_task",
    "arguments": {
      "tenant": ["AXEPA"],
      "role": ["access switch"],
      "platform": ["cisco_xe"],
      "task_type": "cli_command",
      "task_params": { "commands": ["show version"] },
      "nornir_backend": "macbook"
    }
  }
}
```
Response snippet:
```json
{
  "status": "success",
  "results": {
    "AIMOD.C9200.ASW00": {
      "status": "success",
      "commands": {
        "show version": {
          "success": true,
          "output": [
            {
              "hostname": "AIMOD.C9200.ASW00",
              "uptime": "2 years, 4 weeks, 2 days, 22 hours, 12 minutes",
              "version": "16.9.4",
              "model": "C9200L-24P-4X"
            }
          ],
          "parsed": true,
          "error": null
        }
      }
    }
  }
}
```
If no TextFSM template exists, `parsed` is `false` and `output` is a single raw string payload.

### Example (preview inventory before execution)
```json
{
  "jsonrpc": "2.0",
  "id": "inv-1",
  "method": "tools/call",
  "params": {
    "name": "prepare_nornir_inventory",
    "arguments": {
      "tenant": ["AXEPA"],
      "role": ["access switch"],
      "format": "inventory",
      "limit": 10
    }
  }
}
```
The response mirrors a Nornir flat-data inventory payload (`hosts`, `defaults`, `groups`) that can be fed straight into `InitNornir`.

## Workflow Playbooks

### 1. Locate Device by IP / Switch Port

**Goal:** Discover where a device resides (switch + port) using orchestrator tools.

1. `get_devices` (or `prepare_nornir_inventory`) to identify candidate gateways/switches in the device’s VLAN subnet.
2. Use `execute_network_task` with `show ip arp | include <IP>` on the L3 gateway to find the MAC address.
3. `execute_network_task` with `show mac address-table address <MAC>` across access switches (filter by location/role) until the MAC is learned on an access port.
4. If result shows a trunk port, follow cabling from Nautobot (`get_devices` / GraphQL) and repeat step 3 on the next hop.
5. The structured output contains `port`, `vlan`, etc. when templates are available; otherwise parse the raw text field.

### 2. Firewall Investigation

**Goal:** Determine if edge firewall blocks traffic between source/destination.

1. Resolve destination IP (outside the MCP scope). Note source IP.
2. Use `get_devices` to find relevant firewall(s) (role = firewall / tenant = path).
3. Run `execute_network_task` on the firewall backend with commands such as:
   - Cisco ASA/Firepower: `show access-list | include <dst>` or `packet-tracer`
   - Fortigate: `diagnose debug flow ...`
4. Inspect results (structured if template present). Combine with firewall logs if needed.

### 3. Network Path & Health Check

**Goal:** Trace L3 route and evaluate interface KPIs.

1. Identify endpoints via Nautobot (`get_devices` filtering by name/IP).
2. Use `execute_network_task` with `show ip route <dst>` hop-by-hop (filter by platform/role) to build the route.
3. For each interface along the path run `show interface <intf> | include rate|drop|error` and review metrics (TextFSM surfaces counters when templates exist).
4. Summarise findings: high utilisation, CRC errors, drops, etc.

## Best Practices

- **Request inventory format**: For `get_devices` and `prepare_nornir_inventory`, set `format: "inventory"` so downstream tools handle compact JSON.
- **Lean on TextFSM**: The orchestrator exports `NET_TEXTFSM` and calls Nornir with `use_textfsm=True`; template matches return structured rows and `parsed: true`.
- **Graceful fallback**: When `parsed` is `false`, treat `output` as raw text and apply ad hoc parsing (regex, table extraction) client-side.
- **Reuse credentials**: Let the orchestrator perform Vault lookups; it caches per-tenant secrets and shares them with the chosen backend.
- **Pick the right backend**: Prefer the backend already on the VPN path (`macbook` locally, `wyze` in production) to avoid reachability issues.

## Key References

- [`orchestration-mcp/docs`](../../orchestration-mcp/docs) for orchestration setup, agent guidance, and architecture diagrams.
- [`nornir_mcp/docs`](../../nornir_mcp/docs) for Nornir MCP behaviour and TextFSM integration details.
- [`ntc-templates`](../../ntc-templates) for the underlying TextFSM templates.

## TODOs for Skill Enhancements

- Add canned orchestrator tool payloads for common troubleshooting scenarios (ARP lookup, MAC trace, ACL check).
- Automate regression tests for key command templates (`show version`, `show interface`, `packet-tracer`).
- Document fallback parsing examples (regex snippets) for commands without templates.
